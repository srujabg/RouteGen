import os
from flask import Flask, render_template, request, redirect, url_for
import numpy as np
import pandas as pd
import random
from geopy.distance import geodesic
import folium
import time

app = Flask(__name__)

# Updated sample data: List of locations with latitude and longitude
locations = {
    'Location': ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'],
    'Latitude': [12.9715987, 13.0826802, 12.2958104, 12.9718915, 12.2956213, 
                 11.0168445, 10.8505159, 12.914142, 13.337712, 12.285272],
    'Longitude': [77.5945627, 80.2707184, 76.639381, 77.641151, 76.6394,
                  76.9558321, 76.2710833, 74.855957, 77.134899, 76.996589]
}

df = pd.DataFrame(locations)

# Calculate distance matrix
def calculate_distance_matrix(df):
    num_locations = len(df)
    distance_matrix = np.zeros((num_locations, num_locations))

    for i in range(num_locations):
        for j in range(num_locations):
            if i != j:
                distance_matrix[i][j] = geodesic(
                    (df.loc[i, 'Latitude'], df.loc[j, 'Longitude']),
                    (df.loc[j, 'Latitude'], df.loc[j, 'Longitude'])
                ).km

    return distance_matrix

distance_matrix = calculate_distance_matrix(df)

# Genetic Algorithm for TSP
class GeneticAlgorithmTSP:
    def __init__(self, distance_matrix, start_location, population_size=100, mutation_rate=0.01, generations=500):
        self.distance_matrix = distance_matrix
        self.start_location = start_location
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.generations = generations
        self.num_locations = len(distance_matrix)
        self.population = self.initialize_population()

    def initialize_population(self):
        population = []
        for _ in range(self.population_size):
            individual = list(range(self.num_locations))
            individual.remove(self.start_location)
            random.shuffle(individual)
            individual = [self.start_location] + individual + [self.start_location]
            population.append(individual)
        return population

    def fitness(self, individual):
        return 1 / self.calculate_total_distance(individual)

    def calculate_total_distance(self, individual):
        total_distance = 0
        for i in range(len(individual) - 1):
            total_distance += self.distance_matrix[individual[i]][individual[i + 1]]
        return total_distance

    def selection(self):
        selected = random.choices(self.population, weights=[self.fitness(ind) for ind in self.population], k=2)
        return selected

    def crossover(self, parent1, parent2):
        start, end = sorted(random.sample(range(1, self.num_locations - 1), 2))
        child = [-1] * (self.num_locations + 1)
        child[1:start + 1] = parent1[1:start + 1]
        pointer = start + 1
        for gene in parent2:
            if gene not in child and gene != self.start_location:
                while child[pointer % (self.num_locations + 1)] != -1:
                    pointer += 1
                child[pointer % (self.num_locations + 1)] = gene
        child[0] = self.start_location
        child[-1] = self.start_location
        return child

    def mutate(self, individual):
        if random.random() < self.mutation_rate:
            i, j = random.sample(range(1, self.num_locations), 2)
            individual[i], individual[j] = individual[j], individual[i]
        return individual

    def evolve(self):
        new_population = []
        for _ in range(self.population_size):
            parent1, parent2 = self.selection()
            child = self.crossover(parent1, parent2)
            child = self.mutate(child)
            new_population.append(child)
        self.population = new_population

    def run(self):
        best_distance = float('inf')
        best_individual = None
        for generation in range(self.generations):
            self.evolve()
            for individual in self.population:
                distance = self.calculate_total_distance(individual)
                if distance < best_distance:
                    best_distance = distance
                    best_individual = individual
            if generation % 100 == 0:
                print(f'Generation {generation}, Best Distance: {best_distance}')
        time_complexity = 'O(g * p * n)'  # g: number of generations, p: population size, n: number of locations
        space_complexity = 'O(p * n)'
        return best_individual, best_distance, time_complexity, space_complexity

# Nearest Neighbor Algorithm for TSP
def nearest_neighbor_tsp(distance_matrix, start=0):
    num_locations = len(distance_matrix)
    unvisited = list(range(num_locations))
    unvisited.remove(start)
    tour = [start]
    current = start

    while unvisited:
        next_city = min(unvisited, key=lambda city: distance_matrix[current][city])
        tour.append(next_city)
        unvisited.remove(next_city)
        current = next_city

    tour.append(start)  # Return to the starting city
    total_distance = sum(distance_matrix[tour[i]][tour[i + 1]] for i in range(num_locations))
    
    time_complexity = 'O(n^2)'
    space_complexity = 'O(n)'
    return tour, total_distance, time_complexity, space_complexity

# Simulated Annealing Algorithm for TSP
def simulated_annealing_tsp(distance_matrix, start=0, initial_temp=100, cooling_rate=0.995, num_iterations=1000):
    def total_distance(tour):
        return sum(distance_matrix[tour[i]][tour[i + 1]] for i in range(len(tour) - 1)) + distance_matrix[tour[-1]][tour[0]]

    num_locations = len(distance_matrix)
    current_tour = list(range(num_locations))
    current_tour.remove(start)
    random.shuffle(current_tour)
    current_tour = [start] + current_tour + [start]
    current_distance = total_distance(current_tour)
    best_tour = list(current_tour)
    best_distance = current_distance
    temperature = initial_temp

    for _ in range(num_iterations):
        i, j = sorted(random.sample(range(1, num_locations), 2))
        new_tour = current_tour[:]
        new_tour[i:j] = reversed(new_tour[i:j])
        new_distance = total_distance(new_tour)

        if new_distance < current_distance or random.random() < np.exp((current_distance - new_distance) / temperature):
            current_tour, current_distance = new_tour, new_distance

        if new_distance < best_distance:
            best_tour, best_distance = new_tour, new_distance

        temperature *= cooling_rate

    time_complexity = 'O(k * n^2)'  # k: number of iterations, n: number of locations
    space_complexity = 'O(n)'
    return best_tour, best_distance, time_complexity, space_complexity

# Ant Colony Optimization Algorithm for TSP
class AntColonyOptimizationTSP:
    def __init__(self, distance_matrix, num_ants=100, num_iterations=1000, alpha=1, beta=5, evaporation_rate=0.5, pheromone_deposit=100):
        self.distance_matrix = distance_matrix
        self.num_ants = num_ants  # m: number of ants
        self.num_iterations = num_iterations  # k: number of iterations
        self.alpha = alpha
        self.beta = beta
        self.evaporation_rate = evaporation_rate
        self.pheromone_deposit = pheromone_deposit
        self.num_locations = len(distance_matrix)  # n: number of locations
        self.pheromone_matrix = np.ones((self.num_locations, self.num_locations))  # O(n^2) space complexity

    def run(self):
        best_tour = None
        best_distance = float('inf')

        for _ in range(self.num_iterations):
            all_tours = []
            all_distances = []

            for _ in range(self.num_ants):
                tour = self.construct_tour()
                distance = self.calculate_total_distance(tour)
                all_tours.append(tour)
                all_distances.append(distance)

                if distance < best_distance:
                    best_tour = tour
                    best_distance = distance

            self.update_pheromones(all_tours, all_distances)

        time_complexity = 'O(k * n^2 * m)'  # k: number of iterations, n: number of locations, m: number of ants
        space_complexity = 'O(n^2)'
        return best_tour, best_distance, time_complexity, space_complexity

    def construct_tour(self):
        tour = [random.randint(0, self.num_locations - 1)]
        unvisited = set(range(self.num_locations)) - set(tour)

        while unvisited:
            current_city = tour[-1]
            probabilities = self.calculate_probabilities(current_city, unvisited)
            next_city = list(unvisited)[self.select_next_city(probabilities)]
            tour.append(next_city)
            unvisited.remove(next_city)

        tour.append(tour[0])
        return tour

    def calculate_probabilities(self, current_city, unvisited):
        pheromones = np.array([self.pheromone_matrix[current_city][j] for j in unvisited])
        distances = np.array([self.distance_matrix[current_city][j] for j in unvisited])
        desirability = pheromones ** self.alpha * (1 / distances) ** self.beta
        return desirability / desirability.sum()

    def select_next_city(self, probabilities):
        return np.random.choice(len(probabilities), p=probabilities)

    def calculate_total_distance(self, tour):
        return sum(self.distance_matrix[tour[i]][tour[i + 1]] for i in range(len(tour) - 1))

    def update_pheromones(self, all_tours, all_distances):
        self.pheromone_matrix *= (1 - self.evaporation_rate)

        for tour, distance in zip(all_tours, all_distances):
            for i in range(len(tour) - 1):
                self.pheromone_matrix[tour[i]][tour[i + 1]] += self.pheromone_deposit / distance
                self.pheromone_matrix[tour[i + 1]][tour[i]] += self.pheromone_deposit / distance

# Nearest Insertion Algorithm for TSP
def nearest_insertion_tsp(distance_matrix, start=0):
    num_locations = len(distance_matrix)
    tour = [start]
    unvisited = set(range(num_locations))
    unvisited.remove(start)

    # Start by adding the first two nearest cities to the start
    nearest_city = min(unvisited, key=lambda city: distance_matrix[start][city])
    tour.append(nearest_city)
    unvisited.remove(nearest_city)
    tour.append(start)

    while unvisited:
        nearest_city = min(unvisited, key=lambda city: min(distance_matrix[city][tour[i]] for i in range(len(tour))))
        best_position = min(range(1, len(tour)), key=lambda i: distance_matrix[tour[i-1]][nearest_city] + distance_matrix[nearest_city][tour[i]] - distance_matrix[tour[i-1]][tour[i]])
        tour.insert(best_position, nearest_city)
        unvisited.remove(nearest_city)

    total_distance = sum(distance_matrix[tour[i]][tour[i + 1]] for i in range(len(tour) - 1))
    
    time_complexity = 'O(n^2)'
    space_complexity = 'O(n)'
    return tour, total_distance, time_complexity, space_complexity

# Main function to handle form submission and algorithm execution
@app.route('/', methods=['GET', 'POST'])
def index():
    print("Reached the index route")
    if request.method == 'POST':
        print("POST request received")
        algorithm_choices = request.form.getlist('algorithm_choice')
        start_location = int(request.form['start_location'])
        print(f"Algorithm choices: {algorithm_choices}, Start location: {start_location}")

        start_time = time.time()  # Record the start time

        algorithm_colors = {
            '1': 'blue',
            '2': 'green',
            '3': 'red',
            '4': 'purple',
            '5': 'orange'
        }

        routes = []
        for choice in algorithm_choices:
            if choice == '1':
                print("Running Genetic Algorithm...")
                ga_tsp = GeneticAlgorithmTSP(distance_matrix, start_location)
                best_route, best_distance, time_complexity, space_complexity = ga_tsp.run()
                routes.append((best_route, best_distance, time_complexity, space_complexity, "Genetic Algorithm", algorithm_colors[choice]))
            elif choice == '2':
                print("Running Nearest Neighbor Algorithm...")
                best_route, best_distance, time_complexity, space_complexity = nearest_neighbor_tsp(distance_matrix, start=start_location)
                routes.append((best_route, best_distance, time_complexity, space_complexity, "Nearest Neighbor", algorithm_colors[choice]))
            elif choice == '3':
                print("Running Simulated Annealing Algorithm...")
                best_route, best_distance, time_complexity, space_complexity = simulated_annealing_tsp(distance_matrix, start=start_location)
                routes.append((best_route, best_distance, time_complexity, space_complexity, "Simulated Annealing", algorithm_colors[choice]))
            elif choice == '4':
                print("Running Ant Colony Optimization Algorithm...")
                aco_tsp = AntColonyOptimizationTSP(distance_matrix)
                best_route, best_distance, time_complexity, space_complexity = aco_tsp.run()
                routes.append((best_route, best_distance, time_complexity, space_complexity, "Ant Colony Optimization", algorithm_colors[choice]))
            elif choice == '5':
                print("Running Nearest Insertion Algorithm...")
                best_route, best_distance, time_complexity, space_complexity = nearest_insertion_tsp(distance_matrix, start=start_location)
                routes.append((best_route, best_distance, time_complexity, space_complexity, "Nearest Insertion", algorithm_colors[choice]))
            else:
                return "Invalid choice."

        end_time = time.time()  # Record the end time
        execution_time = end_time - start_time  # Calculate the execution time
        print(f'Algorithm Execution Time: {execution_time:.4f} seconds')

        # Visualize the Routes using OpenStreetMap
        map_center = [df.loc[start_location, 'Latitude'], df.loc[start_location, 'Longitude']]
        map_ = folium.Map(location=map_center, zoom_start=6)

        for idx, (best_route, best_distance, time_complexity, space_complexity, algorithm_name, color) in enumerate(routes):
            best_route_coords = [(df.loc[i, 'Latitude'], df.loc[i, 'Longitude']) for i in best_route]
            folium.Marker(location=best_route_coords[0], popup=f'Starting Location {df.loc[best_route[0], "Location"]}', icon=folium.Icon(color='black')).add_to(map_)
            for i, coord in enumerate(best_route_coords):
                if i > 0:
                    folium.Marker(location=coord, popup=f'Stop {i}: {df.loc[best_route[i], "Location"]} ({algorithm_name})', icon=folium.Icon(color=color)).add_to(map_)
                    folium.PolyLine(locations=[best_route_coords[i - 1], best_route_coords[i]], color=color, weight=2.5, opacity=1).add_to(map_)

            # Add line to complete the cycle
            folium.PolyLine(locations=[best_route_coords[-1], best_route_coords[0]], color=color, weight=2.5, opacity=1).add_to(map_)

        # Add Legend
        legend_html = '''
         <div style="position: fixed; 
         bottom: 20px; left: 20px; width: 150px; height: 150px; 
         background-color: white; z-index:9999; font-size:12px;
         border:2px solid grey; padding: 10px;">
         <b>Algorithm Legend</b><br>
         <i class="fa fa-circle" style="color:blue"></i> Genetic Algorithm<br>
         <i class="fa fa-circle" style="color:green"></i> Nearest Neighbor<br>
         <i class="fa fa-circle" style="color:red"></i> Simulated Annealing<br>
         <i class="fa fa-circle" style="color:purple"></i> Ant Colony Optimization<br>
         <i class="fa fa-circle" style="color:orange"></i> Nearest Insertion
         </div>
         '''
        map_.get_root().html.add_child(folium.Element(legend_html))

        # Ensure the 'static' directory exists
        if not os.path.exists('static'):
            os.makedirs('static')

        # Save the map to an HTML file
        map_file = 'static/best_route_map.html'
        map_.save(map_file)
        print("Map saved as best_route_map.html")

        return render_template('result.html', 
                               routes=routes, 
                               map_file=map_file, 
                               execution_time=execution_time)

    return render_template('index.html', locations=df['Location'].tolist())

if __name__ == "__main__":
    app.run(debug=True)
